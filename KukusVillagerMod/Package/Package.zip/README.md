# Kuku's Villager Mod
DELETE OLD VERSION's DLL, CONFIGS EVERY UPDATE.
## Installation (manual)
Paste the plugins folder in valheim/BepInEx/

## Features
1. Place  a bed for them to spawn. If they die there is a Cooldown.
2. Place Defensive Post in locations you want your villagers to guard.
3. Assign defensive post for your villagers by interacting with the bed.
5. Craft a Villager Commander from your crafting Menu to command them.
6. Take them on a journey with you by making them follow you.
7. Command followers to go to a position, or command all villagers to guard their post or respective defense post

## How to :
To spawn villagers you need to craft a bed<br>
The villagers will spawn and get linked to the bed. <br>
To assign it a defense post you need to interact with the bed and then interact with a defense post. This will let the villager know that it has to defend that post <br>
To make a villager follow you, interact with him by tapping your interact key (E default). If you hold your interact key they will go back to guarding their base.<br>
You can craft the villager commander club to command villagers<br>
1. Guard bed : Commands all the villagers to guard their bed
2. Call back Followers : Commands all your followers whom to come back to you.
3. Guard Defense post : Command all your villagers to go to their assigned defense post. 
4,5,6 : Destroy Defense post, Destroy villagers, Destroy bed in area
7. Move To : Command your followers to move to the location you are aiming at.

## Changelog
<h3>2.0.0</h3>
1. Spawn system is based off of Valheim's spawn system which means it is going to be reliable.
2. No more huge fps drops and freezes
3. Revamped the way defense posts are handled. Now you can choose which villager to go to which post.
4. The distance between the beds, posts, villagers no longer matter and will work regardless if they are loaded in memory or not.
5. Changed few commander club commands.
<h3>1.1.0:</h3>  <br>1. Villagers go back to their last state (Guarding Bed or Defending Post) When loaded.<br>2. Replaced Teleport Following Villagers with Move villagers, they will now move to the aimed location and only teleport if moving to that area is not possible.

<h3>1.0.1 : </h3>Added Configurations for heavy customization,<br> Added A new command to teleport following villagers to looking direction. Refined Bed&Villager Link system.

<h3>1.0.0 : </h3> Re-released after updating the code from scratch.

## Future Plans

Plan to make working villagers.


# Mirror Link
https://www.nexusmods.com/valheim/mods/2131