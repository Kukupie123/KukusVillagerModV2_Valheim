# Kuku's Villager Mod
DELETE OLD VERSION's DLL, CONFIGS EVERY UPDATE.
## Installation (manual)
Paste the plugins folder in valheim/BepInEx/

## Features
1. Two types of villagers : Ranged and Melee, All with different strength based on the type of bed created.
2. Place  a bed for them to spawn. If they die there is a Cooldown.
3. Place Defensive Post in locations you want your villagers to guard.
4. Melee Defensive post is where Melee based villagers will go to and guard, Ranged Defensive post is where Ranged Based villagers will go.
5. Craft a Villager Commander from your crafting Menu to command them.

## Recommendations
6. Recommended to keep beds and defensive posts close because of the way game loads and unloads resources
7. The more the villagers, the longer the freeze there will be when they are loaded back in memory. 
8. In case of any bugs Please send me your world and character save so that I can debug.

## Changelog

1.0.1 : Added Configurations for heavy customization, Added A new command to teleport following villagers to looking direction. Refined Bed&Villager Link system.

1.0.0 : Re-released after updating the code from scratch.

## Future Plans

Plan to make working villagers.


# Mirror Link
https://www.nexusmods.com/valheim/mods/2131