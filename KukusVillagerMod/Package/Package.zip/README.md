# Kuku's Villager Mod
DELETE OLD VERSION's DLL AND RECOMMENDED TO START A NEW WORLD IF FACING HEAVY FPS DROP
## Installation (manual)
Paste the plugins folder in valheim/BepInEx/

## Features
1. Two types of villagers : Ranged and Melee, All with different strength based on the type of bed created
2. Place  a bed for them to spawn. If they die there is a 1min Cooldown
3. Place Defensive Post in locations you want your villagers to guard
4. Melee Defensive post is where Melee based villagers will go to and guard, Ranged Defensive post is where Ranged Based villagers will go
5. Craft a Villager Commander from your crafting Menu to command them

## Commands
KeyPad1. Go to their Beds Location and Guard
Keypad2. Aim at a villager and press to make them follow you
Keypad3. Command Villagers to Guard Defensive posts
Keypad4. Delete all nearby Defensive posts
Keypad5. Delete all Nearby villagers

## Changelog

2.0.1 : Fixed a typo in Village Commander

Any version below 2.0.0 is super broken and should be avoided completely

# Link to Mod
https://valheim.thunderstore.io/package/KukuPie/Kukus_Villagers_Mod/
https://www.nexusmods.com/valheim/mods/2131

## Known issues
Leave a comment in Nexus.


If bed is not loaded in your memory but the villager is, the villager will be destroyed once you load the game.
This is intended to prevent redundant villagers in world. A villager MUST have a bed.

If there are other bugs please visit my github repo and create an issue

## Roadmap
Add config for customization
More commands
MAYBE villagers working mechanics (no promises)

